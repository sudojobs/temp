
#!/usr/bin/env python3
# Minimal stdlib server + API (no external deps).

import json, os, re, math, time, io, traceback
from http.server import SimpleHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse
from pathlib import Path

# Load config
ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))

UI_DIR = ROOT / "ui"
GEN_DIR = ROOT / "generated"
MODEL_PATH = ROOT / CONFIG["model_path"]
RECIPES = CONFIG.get("recipes", {})

# ---------------- TF-IDF Utilities (no third-party deps) -----------------
def tokenize(text, lowercase=True):
    if lowercase:
        text = text.lower()
    toks = re.findall(r"[a-z0-9_#\.\-/]+", text)
    return toks

def ngrams(tokens, ngram_sizes):
    toks = []
    for n in ngram_sizes:
        for i in range(len(tokens)-n+1):
            toks.append(" ".join(tokens[i:i+n]))
    return toks

def build_vocab_and_idf(docs, config):
    # docs: list of token lists (already ngrammed)
    N = len(docs)
    df = {}
    for tokens in docs:
        seen = set(tokens)
        for t in seen:
            df[t] = df.get(t, 0) + 1
    vocab = {t:i for i,t in enumerate(sorted(df.keys()))}
    idf = [0.0] * len(vocab)
    for t, i in vocab.items():
        idf[i] = math.log((1 + N) / (1 + df[t])) + 1.0
    return vocab, idf

def vectorize(tokens, vocab, idf):
    tf = {}
    for t in tokens:
        if t in vocab:
            tf[t] = tf.get(t, 0) + 1
    vec = [0.0]*len(vocab)
    norm = 0.0
    for t, c in tf.items():
        i = vocab[t]
        w = (1.0 + math.log(c)) * idf[i]
        vec[i] = w
        norm += w*w
    norm = math.sqrt(norm) or 1.0
    vec = [v/norm for v in vec]
    return vec

def cosine(a, b):
    s = 0.0
    for i in range(min(len(a), len(b))):
        s += a[i]*b[i]
    return s


# ---------------- Optional Local LLM (Ollama) -----------------

# ---------------- Optional llama.cpp runner (no installation if binary dropped in ./bin) -----------------
def llama_local_generate(prompt, model_path="models/model.gguf", bin_path="bin/llama", temperature=0.1, max_tokens=2048):
    """
    If the user drops a llama.cpp binary into ./bin and a GGUF model into ./models,
    this function will run it and return the output. Otherwise it raises.
    """
    exe = ROOT / bin_path
    mdl = ROOT / model_path
    if not exe.exists():
        raise RuntimeError("llama.cpp binary not found at ./bin/llama")
    if not mdl.exists():
        raise RuntimeError("GGUF model not found at ./models/model.gguf")
    import subprocess, tempfile, shlex, sys
    with tempfile.NamedTemporaryFile("w+", delete=False, encoding="utf-8") as tf:
        tf.write(prompt); tf.flush()
        cmd = [str(exe), "-m", str(mdl), "-p", f"@@PROMPT@@", "-n", str(max_tokens), "--temp", str(temperature)]
        # Replace placeholder safely for Windows
        cmd = [c if c != "@@PROMPT@@" else open(tf.name, "r", encoding="utf-8").read() for c in cmd]
        out = subprocess.run(cmd, capture_output=True, text=True)
        if out.returncode != 0:
            raise RuntimeError("llama.cpp failed: " + out.stderr[:4000])
        return out.stdout

def ollama_generate(prompt, model, host, temperature=0.1, max_tokens=2048):
    import json, urllib.request
    data = json.dumps({
        "model": model,
        "prompt": prompt,
        "options": {"temperature": float(temperature), "num_predict": int(max_tokens)},
        "stream": False
    }).encode("utf-8")
    req = urllib.request.Request(
        url=host.rstrip("/") + "/api/generate",
        data=data,
        headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=600) as resp:
        out = json.loads(resp.read().decode("utf-8"))
    return out.get("response","")

def build_llm_prompt(jira_text, similar):
    # similar: list of dicts with id, summary, fix
    sim_txt = "\n".join([f"- {s['id']}: {s['summary']} | fix: {s.get('fix','')}" for s in similar]) if similar else "None"
    from recipes.templates import extract_features
    feats = extract_features(jira_text)
    clocks = ", ".join(feats.get("clocks", [])) or "/*clk*/"
    resets = ", ".join(feats.get("resets", [])) or "/*rst*/"
    signals = ", ".join(feats.get("signals", [])) or "/*signals*/"
    return f"""
You are a senior DV engineer. Create *compilable* **SystemVerilog UVM 1.2** skeletons to reproduce and catch the bug described below.
Make four files with stubs that compile:
1) RUN.md — brief compile/run tips
2) tb_pkg.sv — package, run_test hook
3) seq.sv — realistic stimulus to reproduce the issue
4) uvm_test.sv — config, phases, simple coverage & SVA TODOs

Context:
- Clocks: {clocks}
- Resets: {resets}
- Suspect signals: {signals}
- Similar old fixes:
{sim_txt}

Guidelines:
- No vendor-specific code, UVM 1.2 compatible.
- Insert TODOs where DUT/env bindings are needed.
- Provide at least one covergroup stub and one assertion stub.

Write the four files in this strict order with clear fenced blocks and only file content inside each block.
---
JIRA:
{jira_text}
---
""".strip()

# ---------------- Model persistence -----------------
def load_model():
    if not MODEL_PATH.exists():
        return None
    data = json.loads(MODEL_PATH.read_text(encoding="utf-8"))
    # Convert lists to what's needed
    return data

def save_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2), encoding="utf-8")


# ---------------- PDF ingestion (no external deps required) -----------------
def _which(cmd):
    import shutil as _sh
    return _sh.which(cmd)

def extract_text_from_pdf_bytes(data: bytes) -> str:
    """
    Try poppler's pdftotext if available; else do a naive extraction of BT..ET and (...) strings.
    This fallback will not reconstruct layout but is offline and zero-dep.
    """
    try:
        if _which("pdftotext"):
            import tempfile, subprocess
            with tempfile.TemporaryDirectory() as td:
                pdfp = Path(td) / "in.pdf"
                txtp = Path(td) / "out.txt"
                pdfp.write_bytes(data)
                subprocess.run(["pdftotext", "-q", str(pdfp), str(txtp)], check=True)
                return txtp.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        pass

    # naive fallback
    s = data.decode("latin-1", errors="ignore")
    # Extract content streams between BT...ET, then pull text in parentheses
    chunks = []
    for bt in re.finditer(r"BT(.*?)ET", s, re.S):
        block = bt.group(1)
        for m in re.finditer(r"\((.*?)\)", block, re.S):
            # Unescape common sequences
            text = m.group(1)
            text = text.replace(r"\(", "(").replace(r"\)", ")").replace(r"\\", "\\")
            chunks.append(text)
    return "\n".join(chunks)

def pdf_chunker(text: str, max_len=800, overlap=120):
    words = re.findall(r"\S+", text)
    chunks = []
    i = 0
    while i < len(words):
        chunk = " ".join(words[i:i+max_len])
        if chunk.strip():
            chunks.append(chunk)
        i += max_len - overlap if (max_len - overlap) > 0 else max_len
    return chunks

def ensure_pdf_store():
    store = ROOT / "pdf_store"
    store.mkdir(parents=True, exist_ok=True)
    (store / "index.json").touch(exist_ok=True)
    # schema: {"docs":[{"id":str,"name":str,"chunks":[{"txt":str,"vec":[...]}]}], "cfg":{...}}
    try:
        data = json.loads((store / "index.json").read_text(encoding="utf-8") or "{}")
    except Exception:
        data = {}
    if "docs" not in data: data["docs"] = []
    (store / "index.json").write_text(json.dumps(data, indent=2), encoding="utf-8")
    return store

def load_pdf_index():
    store = ensure_pdf_store()
    try:
        return json.loads((store / "index.json").read_text(encoding="utf-8"))
    except Exception:
        return {"docs":[]}

def save_pdf_index(obj):
    store = ensure_pdf_store()
    (store / "index.json").write_text(json.dumps(obj, indent=2), encoding="utf-8")

# ---------------- Recipes -----------------
def _read_files_dict(paths):
    out = {}
    for p in paths:
        try:
            out[p.name] = (p.read_text(encoding='utf-8'))
        except Exception:
            out[p.name] = ''
    return out

from recipes.templates import generate_sv_bundle, request_data_checklist, provide_options

# ---------------- Request handler -----------------
class Handler(SimpleHTTPRequestHandler):
    def _set_headers(self, code=200, content_type="application/json"):
        self.send_response(code)
        self.send_header("Content-Type", content_type)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.end_headers()

    def do_OPTIONS(self):
        self._set_headers(200)

    
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/config":
            self._set_headers(200)
            self.wfile.write(json.dumps(CONFIG).encode("utf-8")); return
        if parsed.path == "/api/stream_llm":
            # query: ?text=...&model=...&temp=...
            from urllib.parse import parse_qs
            qs = parse_qs(parsed.query or "")
            text = (qs.get("text", [""])[0]).strip()
            model = (qs.get("model", [CONFIG.get("llm",{}).get("model","")])[0])
            temp = float((qs.get("temp", [str(CONFIG.get("llm",{}).get("temperature",0.1))])[0]))
            model_cfg = CONFIG.get("llm", {})
            if not (model_cfg.get("enabled") and model_cfg.get("adapter") == "ollama"):
                self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "error": "llm_disabled"}).encode()); return

            # Prepare prompt with top matches
            similar = []
            model_obj = load_model()
            if model_obj and len(text) >= CONFIG.get("min_chars",20):
                stop = set(model_obj["stopwords"])
                toks = [t for t in tokenize(text, model_obj.get("lowercase",True)) if t not in stop]
                toks = ngrams(toks, model_obj["ngrams"])
                vocab = {t:i for i,t in enumerate(model_obj["vocab"])}
                qvec = vectorize(toks, vocab, model_obj["idf"])
                scored = []
                for d in model_obj["docvecs"]:
                    s = cosine(qvec, d["vec"])
                    scored.append((s, d))
                scored.sort(key=lambda x: x[0], reverse=True)
                similar = [{"id": d["id"], "summary": d["summary"], "fix": d.get("fix",""), "score": round(s,4)} for s,d in scored[:3]]

            prompt = build_llm_prompt(text, similar)

            # Begin SSE
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "keep-alive")
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()

            # Stream tokens from Ollama
            import json as _json, urllib.request as _urlreq
            data = _json.dumps({
                "model": model or model_cfg.get("model"),
                "prompt": prompt,
                "options": {"temperature": float(temp)},
                "stream": True
            }).encode("utf-8")
            req = _urlreq.Request(url=model_cfg.get("ollama_host","").rstrip("/") + "/api/generate", data=data, headers={"Content-Type": "application/json"})
            acc = ""
            try:
                with _urlreq.urlopen(req, timeout=0) as resp:  # chunked
                    for raw in resp:
                        try:
                            part = _json.loads(raw.decode("utf-8"))
                        except Exception:
                            continue
                        tok = part.get("response","")
                        if tok:
                            acc += tok
                            self.wfile.write(f"data: {tok}

".encode("utf-8"))
                            self.wfile.flush()
                        if part.get("done"):
                            break
            except Exception as e:
                self.wfile.write(f"data: [STREAM_ERROR] {e}

".encode("utf-8"))
                self.wfile.flush()

            # Parse files from acc and save
            files = {"RUN.md":"","tb_pkg.sv":"","seq.sv":"","uvm_test.sv":""}
            current = None
            for line in acc.splitlines():
                ls = line.strip()
                if ls.lower().startswith("```"): continue
                if "RUN.md" in ls and current is None: current="RUN.md";   continue
                if "tb_pkg.sv" in ls and (current is None or current=="RUN.md"): current="tb_pkg.sv"; continue
                if "seq.sv" in ls and current!="uvm_test.sv": current="seq.sv"; continue
                if "uvm_test.sv" in ls: current="uvm_test.sv"; continue
                if current: files[current] += line + "
"

            outdir = GEN_DIR / "llm_testcase"
            outdir.mkdir(parents=True, exist_ok=True)
            for n,c in files.items():
                (outdir / n).write_text(c.strip()+"
", encoding="utf-8")
            # zip
            zip_path = GEN_DIR / "testcase_latest.zip"
            import zipfile as _zip
            with _zip.ZipFile(zip_path, 'w', compression=_zip.ZIP_DEFLATED) as z:
                for p in outdir.rglob('*'):
                    z.write(p, p.relative_to(outdir))

            final = _json.dumps({"done": True, "similar": similar, "zip": "/download/testcase_latest.zip"})
            self.wfile.write(f"data: {final}

".encode("utf-8"))
            self.wfile.flush()
            return

        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        body = self.rfile.read(length) if length else b"{}"
        try:
            payload = json.loads(body.decode("utf-8") or "{}")
        except:
            payload = {}

        try:

            if parsed.path == "/api/config/update":
                # payload can contain {"recipes": {...}} and/or {"llm": {...}}
                changed = {}
                if "recipes" in payload and isinstance(payload["recipes"], dict):
                    CONFIG["recipes"].update(payload["recipes"])
                    changed["recipes"] = CONFIG["recipes"]
                if "llm" in payload and isinstance(payload["llm"], dict):
                    CONFIG["llm"].update(payload["llm"])
                    changed["llm"] = CONFIG["llm"]
                # persist config
                (ROOT / "config.json").write_text(json.dumps(CONFIG, indent=2), encoding="utf-8")
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "config": CONFIG}).encode("utf-8"))
                return

            if parsed.path == "/api/pdf_upload":
                # multipart form-data expected with field "file"
                ctype = self.headers.get("Content-Type","")
                if "multipart/form-data" not in ctype:
                    self._set_headers(400); self.wfile.write(json.dumps({"ok":False,"error":"multipart_required"}).encode()); return
                # read raw body
                length = int(self.headers.get("Content-Length","0"))
                raw = self.rfile.read(length)
                # parse multipart boundary
                m = re.search(b"boundary=(.+)", ctype.encode())
                if not m:
                    self._set_headers(400); self.wfile.write(json.dumps({"ok":False,"error":"no_boundary"}).encode()); return
                boundary = b"--" + m.group(1)
                # extract file content (very simple multipart parser)
                parts = raw.split(boundary)
                pdf_bytes = b""; filename = "upload.pdf"
                for part in parts:
                    if b"Content-Disposition" in part and b'name="file"' in part:
                        # filename
                        m2 = re.search(br'filename="([^"]+)"', part)
                        if m2: filename = m2.group(1).decode(errors="ignore")
                        # split headers/body
                        sep = b"\r\n\r\n"
                        idx = part.find(sep)
                        if idx != -1:
                            pdf_bytes = part[idx+len(sep):]
                            pdf_bytes = pdf_bytes.rstrip(b"\r\n--")
                        break
                if not pdf_bytes:
                    self._set_headers(400); self.wfile.write(json.dumps({"ok":False,"error":"no_file"}).encode()); return

                text = extract_text_from_pdf_bytes(pdf_bytes)
                chunks = pdf_chunker(text, max_len=800, overlap=120)

                # vectorize with current config
                model_cfg = load_model()  # use same tokenizer/params as Jira TF-IDF but compute fresh idf for PDF doc alone
                # Build a "local" vocab/idf for mixed corpus = existing pdf docs + new doc
                idx = load_pdf_index()
                all_docs_tokens = []
                def tokpipe(t):
                    lower = CONFIG.get("lowercase", True)
                    stop = set(CONFIG.get("stopwords", []))
                    toks = [tt for tt in tokenize(t, lower) if tt not in stop]
                    return ngrams(toks, CONFIG.get("ngrams",[1,2]))
                for d in idx.get("docs", []):
                    for ch in d.get("chunks", []):
                        all_docs_tokens.append(tokpipe(ch["txt"]))
                # include new chunks
                new_tokens = [tokpipe(ch) for ch in chunks]
                all_docs_tokens.extend(new_tokens)

                if all_docs_tokens:
                    vocab, idf = build_vocab_and_idf(all_docs_tokens, CONFIG)
                else:
                    vocab, idf = {}, []

                # vectorize chunks
                doc_chunks = []
                for ch, toks in zip(chunks, new_tokens):
                    vec = vectorize(toks, {t:i for i,t in enumerate(sorted(vocab.keys()))}, idf) if vocab else []
                    doc_chunks.append({"txt": ch, "vec": vec})

                doc_id = f"PDF-{int(time.time())}"
                idx["docs"].append({"id": doc_id, "name": filename, "chunks": doc_chunks})
                save_pdf_index(idx)

                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "doc_id": doc_id, "name": filename, "chunks": len(chunks)}).encode())
                return

            if parsed.path == "/api/pdf_list":
                idx = load_pdf_index()
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "docs": [{"id":d["id"],"name":d["name"],"chunks":len(d.get("chunks",[]))} for d in idx.get("docs",[])]}).encode())
                return

            if parsed.path == "/api/pdf_query":
                q = payload.get("q","").strip()
                if not q:
                    self._set_headers(200); self.wfile.write(json.dumps({"ok":False,"error":"empty_query"}).encode()); return
                idx = load_pdf_index()
                # Build vocab from all chunks
                all_tokens = []
                def tokpipe(t):
                    lower = CONFIG.get("lowercase", True)
                    stop = set(CONFIG.get("stopwords", []))
                    toks = [tt for tt in tokenize(t, lower) if tt not in stop]
                    return ngrams(toks, CONFIG.get("ngrams",[1,2]))
                for d in idx.get("docs", []):
                    for ch in d.get("chunks", []):
                        all_tokens.append(tokpipe(ch["txt"]))
                if not all_tokens:
                    self._set_headers(200); self.wfile.write(json.dumps({"ok":False,"error":"no_pdf_corpus"}).encode()); return
                vocab, idf = build_vocab_and_idf(all_tokens, CONFIG)
                vocab_map = {t:i for i,t in enumerate(sorted(vocab.keys()))}

                qvec = vectorize(tokpipe(q), vocab_map, idf)

                # score all chunks
                scored = []
                for d in idx.get("docs", []):
                    for i, ch in enumerate(d.get("chunks", [])):
                        vec = ch.get("vec")
                        if not vec or len(vec) != len(qvec):
                            # revectorize with current vocab
                            vec = vectorize(tokpipe(ch["txt"]), vocab_map, idf)
                            ch["vec"] = vec
                        s = cosine(qvec, vec)
                        scored.append((s, d["id"], d["name"], i, ch["txt"]))
                scored.sort(key=lambda x: x[0], reverse=True)
                top_k = CONFIG.get("top_k",5)
                results = [{"score": round(s,4), "doc_id": did, "name": name, "chunk_index": idx, "text": txt[:800]} for s,did,name,idx,txt in scored[:top_k]]
                save_pdf_index(idx)  # persist any new vecs
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok":True, "results": results}).encode())
                return

            if parsed.path == "/api/train":
                # payload expects CSV path (optional). Reads config otherwise.
                csv_path = payload.get("csv_path", CONFIG["training_data"])
                csv_path = (ROOT / csv_path)
                rows = []
                with csv_path.open("r", encoding="utf-8") as f:
                    import csv
                    r = csv.DictReader(f)
                    for row in r:
                        rows.append({
                            "id": row.get("id",""),
                            "summary": row.get("summary",""),
                            "description": row.get("description",""),
                            "fix": row.get("fix","")
                        })
                # Build docs
                ngram_sizes = CONFIG.get("ngrams",[1,2])
                stop = set(CONFIG.get("stopwords",[]))
                docs = []
                for row in rows:
                    text = " ".join([row["summary"], row["description"], row["fix"]])
                    toks = [t for t in tokenize(text, CONFIG.get("lowercase",True)) if t not in stop]
                    toks = ngrams(toks, ngram_sizes)
                    docs.append(toks)
                vocab, idf = build_vocab_and_idf(docs, CONFIG)
                # Vectorize docs
                docvecs = []
                for row, toks in zip(rows, docs):
                    vec = vectorize(toks, vocab, idf)
                    docvecs.append({"id": row["id"], "summary": row["summary"], "fix": row["fix"], "vec": vec})
                model = {
                    "vocab": list(vocab.keys()),
                    "idf": idf,
                    "docvecs": docvecs,
                    "ngrams": ngram_sizes,
                    "lowercase": CONFIG.get("lowercase",True),
                    "stopwords": list(stop),
                    "timestamp": time.time()
                }
                save_json(MODEL_PATH, model)
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "docs": len(rows), "model_path": str(MODEL_PATH)}).encode("utf-8"))
                return

            if parsed.path == "/api/match_old_fixes":
                if not RECIPES.get("matched_old_fixes", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                q = payload.get("text","")
                if len(q) < CONFIG.get("min_chars",20):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "error": "too_short"}).encode()); return
                model = load_model()
                if not model:
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "error": "model_missing"}).encode()); return
                stop = set(model["stopwords"])
                toks = [t for t in tokenize(q, model.get("lowercase", True)) if t not in stop]
                toks = ngrams(toks, model["ngrams"])
                # Build vocab map from model["vocab"]
                vocab = {t:i for i,t in enumerate(model["vocab"])}
                qvec = vectorize(toks, vocab, model["idf"])
                scored = []
                for d in model["docvecs"]:
                    score = cosine(qvec, d["vec"])
                    scored.append((score, d))
                scored.sort(key=lambda x: x[0], reverse=True)
                top_k = CONFIG.get("top_k",5)
                results = [{"score": round(s,4), **d} for s,d in scored[:top_k]]
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "results": results}).encode("utf-8"))
                return

            if parsed.path == "/api/generate_testcase":
                if not RECIPES.get("generate_testcase", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                jira_text = payload.get("jira_text","")
                names = {
                    "test_name": payload.get("test_name","auto_repro_test"),
                    "seq_name": payload.get("seq_name","auto_repro_seq"),
                    "pkg_name": payload.get("pkg_name","auto_tb_pkg")
                }
                outdir = GEN_DIR / "testcase"
                from recipes.templates import generate_sv_bundle
                files = generate_sv_bundle(outdir, jira_text, names)
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "files": [str(outdir / f) for f in files], "contents": _read_files_dict([outdir / f for f in files])}).encode("utf-8"))
                return

            if parsed.path == "/api/request_data":
                if not RECIPES.get("request_data", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                from recipes.templates import request_data_checklist
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "checklist": request_data_checklist()}).encode("utf-8"))
                return

            if parsed.path == "/api/profiling":
                if not RECIPES.get("profiling", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                # Dummy profiling info (extend as needed)
                info = {
                    "uptime_sec": time.time(),
                    "recipes_enabled": RECIPES
                }
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "profile": info}).encode("utf-8"))
                return


            if parsed.path == "/api/generate_llm_testcase":
                if not RECIPES.get("generate_testcase", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                jira_text = payload.get("jira_text","").strip()
                model_cfg = CONFIG.get("llm", {})
                if not (model_cfg.get("enabled") and model_cfg.get("adapter") == "ollama"):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "error": "llm_disabled"}).encode()); return

                # Use matcher to fetch top-3 similar fixes (if model exists)
                similar = []
                model = load_model()
                if model and len(jira_text) >= CONFIG.get("min_chars",20):
                    stop = set(model["stopwords"])
                    toks = [t for t in tokenize(jira_text, model.get("lowercase",True)) if t not in stop]
                    toks = ngrams(toks, model["ngrams"])
                    vocab = {t:i for i,t in enumerate(model["vocab"])}
                    qvec = vectorize(toks, vocab, model["idf"])
                    scored = []
                    for d in model["docvecs"]:
                        s = cosine(qvec, d["vec"])
                        scored.append((s, d))
                    scored.sort(key=lambda x: x[0], reverse=True)
                    similar = [{"id": d["id"], "summary": d["summary"], "fix": d.get("fix",""), "score": round(s,4)} for s,d in scored[:3]]

                # Build prompt and call Ollama
                prompt = build_llm_prompt(jira_text, similar)
                try:
                    llm_out = ollama_generate(prompt, model_cfg["model"], model_cfg["ollama_host"], model_cfg.get("temperature",0.1), model_cfg.get("max_tokens",2048))
                except Exception as e:
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "error": f"ollama_error: {e}"}).encode()); return

                # Parse files
                files = {"RUN.md":"","tb_pkg.sv":"","seq.sv":"","uvm_test.sv":""}
                current = None
                for line in llm_out.splitlines():
                    ls = line.strip()
                    if ls.lower().startswith("```"): continue
                    if "RUN.md" in ls and current is None: current="RUN.md";   continue
                    if "tb_pkg.sv" in ls and (current is None or current=="RUN.md"): current="tb_pkg.sv"; continue
                    if "seq.sv" in ls and current!="uvm_test.sv": current="seq.sv"; continue
                    if "uvm_test.sv" in ls: current="uvm_test.sv"; continue
                    if current: files[current] += line + "\n"

                # Save bundle
                outdir = GEN_DIR / "llm_testcase"
                outdir.mkdir(parents=True, exist_ok=True)
                for n, c in files.items():
                    (outdir / n).write_text(c.strip()+"\n", encoding="utf-8")

                # Zip for download
                zip_path = GEN_DIR / "testcase_latest.zip"
                import zipfile
                with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                    for p in outdir.rglob('*'):
                        z.write(p, p.relative_to(outdir))

                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "similar": similar, "files": [str(outdir / n) for n in files], "contents": _read_files_dict([outdir / n for n in files]), "zip": "/download/testcase_latest.zip"}).encode("utf-8"))
                return

            if parsed.path == "/download/testcase_latest.zip":
                p = GEN_DIR / "testcase_latest.zip"
                if not p.exists():
                    self._set_headers(404); self.wfile.write(b"No bundle yet."); return
                self._set_headers(200, "application/zip")
                self.wfile.write(p.read_bytes())
                return

            if parsed.path == "/api/options":
                if not RECIPES.get("provide_options", True):
                    self._set_headers(200); self.wfile.write(json.dumps({"ok": False, "disabled": True}).encode()); return
                from recipes.templates import provide_options
                self._set_headers(200)
                self.wfile.write(json.dumps({"ok": True, "options": provide_options()}).encode("utf-8"))
                return

            # Fallback
            self._set_headers(404)
            self.wfile.write(json.dumps({"ok": False, "error": "not_found"}).encode("utf-8"))
        except Exception as e:
            self._set_headers(200)
            self.wfile.write(json.dumps({"ok": False, "error": str(e), "trace": traceback.format_exc()}).encode("utf-8"))

def main():
    os.chdir(ROOT)  # serve UI files relative to project
    server = HTTPServer((CONFIG["host"], CONFIG["port"]), Handler)
    print(f"Serving {CONFIG['app_name']} at http://{CONFIG['host']}:{CONFIG['port']}/")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Shutting down...")
    finally:
        server.server_close()

if __name__ == "__main__":
    main()
