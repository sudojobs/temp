# RUN.md
Steps to compile and run (example, adjust to your toolchain):

1. Compile:
   ```sh
   vlog -sv tb_pkg.sv seq.sv uvm_test.sv
   ```

2. Run:
   ```sh
   vsim -c -do "run -all" -sv_lib tb_pkg +UVM_TESTNAME=auto_repro_test
   ```

3. TODO: Bind your DUT and env in `tb_pkg.sv` and connect agents.
