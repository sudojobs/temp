
#!/usr/bin/env python3
import json, csv, re, math, time
from pathlib import Path

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / "config.json").read_text(encoding="utf-8"))
MODEL_PATH = ROOT / CONFIG["model_path"]

def tokenize(text, lowercase=True):
    if lowercase: text = text.lower()
    return re.findall(r"[a-z0-9_#\.\-/]+", text)

def ngrams(tokens, ngram_sizes):
    toks = []
    for n in ngram_sizes:
        for i in range(len(tokens)-n+1):
            toks.append(" ".join(tokens[i:i+n]))
    return toks

def build_vocab_and_idf(docs, N):
    df = {}
    for tokens in docs:
        seen = set(tokens)
        for t in seen:
            df[t] = df.get(t, 0) + 1
    vocab = {t:i for i,t in enumerate(sorted(df.keys()))}
    idf = [0.0]*len(vocab)
    for t,i in vocab.items():
        idf[i] = math.log((1 + N) / (1 + df[t])) + 1.0
    return vocab, idf

def vectorize(tokens, vocab, idf):
    tf = {}
    for t in tokens:
        if t in vocab:
            tf[t] = tf.get(t, 0) + 1
    vec = [0.0]*len(vocab)
    norm = 0.0
    for t,c in tf.items():
        i = vocab[t]
        w = (1.0 + math.log(c)) * idf[i]
        vec[i] = w
        norm += w*w
    norm = math.sqrt(norm) or 1.0
    vec = [v/norm for v in vec]
    return vec

def main():
    csv_path = ROOT / CONFIG["training_data"]
    rows = []
    with csv_path.open("r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            rows.append({
                "id": row.get("id",""),
                "summary": row.get("summary",""),
                "description": row.get("description",""),
                "fix": row.get("fix","")
            })
    ngram_sizes = CONFIG.get("ngrams",[1,2])
    stop = set(CONFIG.get("stopwords",[]))
    docs = []
    for row in rows:
        text = " ".join([row["summary"], row["description"], row["fix"]])
        toks = [t for t in tokenize(text, CONFIG.get("lowercase",True)) if t not in stop]
        toks = ngrams(toks, ngram_sizes)
        docs.append(toks)

    vocab, idf = build_vocab_and_idf(docs, len(docs))
    docvecs = []
    for row, toks in zip(rows, docs):
        vec = vectorize(toks, vocab, idf)
        docvecs.append({"id": row["id"], "summary": row["summary"], "fix": row["fix"], "vec": vec})

    model = {
        "vocab": list(vocab.keys()),
        "idf": idf,
        "docvecs": docvecs,
        "ngrams": ngram_sizes,
        "lowercase": CONFIG.get("lowercase",True),
        "stopwords": list(stop),
        "timestamp": time.time()
    }
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    MODEL_PATH.write_text(json.dumps(model, indent=2), encoding="utf-8")
    print(f"Model saved -> {MODEL_PATH} (docs={len(rows)})")

if __name__ == "__main__":
    main()
