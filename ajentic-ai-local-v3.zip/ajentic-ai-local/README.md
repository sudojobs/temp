# Ajentic AI (Offline / Local)

A fully local, easy-deployable tool to assist DV/verification workflows around Jira issues. 
Runs with **no third‑party Python packages** (only standard library) and works on restricted networks.

## Features (Recipes)
1. **Generate a Testcase** — produce SystemVerilog/UVM skeletons from Jira-like text (heuristics + templates; optional local LLM adapter).
2. **Request Data** — checklist template for repro info from reporters.
3. **Matched with Old Fixes** — TF‑IDF model trained on your historical Jira list to surface similar items and fixes.
4. **Profiling** — simple timing and scoring diagnostics for decisions taken.
5. **Provide Options** — shows suggested next actions (e.g., generate seq only, ask for logs, open matched diffs).

## Layout
```
ajentic-ai-local/
  config.json
  server.py
  train.py
  data/jira_seed.csv           # put your historic Jira here (CSV example included)
  models/jira_tfidf_model.json # produced by train.py
  ui/index.html
  ui/app.js
  recipes/templates.py         # code templates + checklists
  generated/                   # generated outputs
```

## Quick Start (Linux or Windows with Python 3.9+)
1. Put your past Jira data into `data/jira_seed.csv` (columns: `id,summary,description,fix`).
2. Train local TF‑IDF model:
   ```bash
   python train.py
   ```
   This creates `models/jira_tfidf_model.json`.
3. Run the local server:
   ```bash
   python server.py
   ```
4. Open the UI at http://localhost:8099/ and try a query.

> Offline note: No internet is required. You can *optionally* enable a local LLM (Ollama) in `config.json` (`llm.enabled=true`), otherwise the code generator uses robust templates.

## Packaging for offline machines
- Zip/tar this folder and copy to the target machine.
- Python 3.9+ must be available on the machine (no pip install needed).
- For Windows, double-click `server.py` or run `py server.py` from cmd/PowerShell.

## Configuration
See `config.json` for:
- `recipes` to switch features on/off.
- `ngrams`, `stopwords`, `top_k` for TF‑IDF search.
- `llm` section to point to a local Ollama server (optional).

