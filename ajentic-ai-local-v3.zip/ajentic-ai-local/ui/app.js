
let filesCache = {};

function setCfgSummary(cfg){
  const r = cfg.recipes || {};
  const on = Object.keys(r).filter(k=>r[k]).length;
  const total = Object.keys(r).length;
  document.getElementById("cfgsummary").textContent = `Recipes ON: ${on}/${total} | Port ${cfg.port}`;
  // Reflect LLM config into dropdown
  if(cfg.llm && cfg.llm.model){
    document.getElementById("model").value = cfg.llm.model;
  }
  if(cfg.llm && typeof cfg.llm.temperature === "number"){
    document.getElementById("temp").value = cfg.llm.temperature;
  }
}

async function getConfig(){
  const r = await fetch("/api/config");
  const cfg = await r.json();
  setCfgSummary(cfg);
}
getConfig();

function switchTab(el){
  document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
  el.classList.add("active");
  const tab = el.getAttribute("data-tab");
  document.getElementById("out").style.display = tab==="out"?"block":"none";
  document.getElementById("preview").style.display = tab==="preview"?"block":"none";
}

function jiraText(){ return document.getElementById("jira").value.trim(); }

function showOut(obj){
  document.getElementById("outpre").textContent = typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
}

async function train(){
  showOut("Training TF-IDF...");
  const r = await fetch("/api/train", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({})});
  const j = await r.json();
  showOut(j);
}

async function match(){
  const text = jiraText();
  const r = await fetch("/api/match_old_fixes", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({text})});
  const j = await r.json();
  showOut(j);
}

async function genHeuristic(){
  const jira_text = jiraText();
  const payload = {jira_text, test_name:"auto_repro_test", seq_name:"auto_repro_seq", pkg_name:"auto_tb_pkg"};
  const r = await fetch("/api/generate_testcase", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)});
  const j = await r.json();
  showOut(j);
  if(j.ok && j.files){
    filesCache = {};
    const sel = document.getElementById("pvsel");
    sel.innerHTML = "";
    for(const path of j.files){
      const name = path.split("/").pop();
      filesCache[name] = {path, content:null};
      const opt = document.createElement("option");
      opt.value = name; opt.textContent = name;
      sel.appendChild(opt);
    }
    document.querySelector('[data-tab="preview"]').click();
    loadPreview();
  }
}

async function genLLM(){
  const jira_text = jiraText();
  const model = document.getElementById("model").value;
  const temperature = parseFloat(document.getElementById("temp").value||"0.1");
  // also persist to config at runtime (in-memory only; server uses config.json defaults otherwise)
  const r = await fetch("/api/generate_llm_testcase", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({jira_text, llm:{model, temperature}})});
  const j = await r.json();
  showOut(j);
  if(j.ok && j.files){
    const sel = document.getElementById("pvsel");
    sel.innerHTML = "";
    filesCache = {};
    for(const path of j.files){
      const name = path.split("/").pop();
      filesCache[name] = {path, content:null};
      const opt = document.createElement("option");
      opt.value = name; opt.textContent = name;
      sel.appendChild(opt);
    }
    const dl = document.getElementById("dl");
    if(j.zip){ dl.style.display="inline-block"; dl.href = j.zip; }
    document.querySelector('[data-tab="preview"]').click();
    loadPreview();
  }
}

async function loadPreview(){
  const sel = document.getElementById("pvsel");
  const name = sel.value;
  const item = filesCache[name];
  if(!item) return;
  // Fetch file content via plain GET (server serves static cwd root only for / and /ui/, so disable; show path hint instead)
  document.getElementById("pv").textContent = `Open on disk: ${item.path}\n\n(Use the download button for a zip bundle.)`;
}

document.getElementById("pvsel").addEventListener("change", loadPreview);
