
import re, time, os, json
from pathlib import Path

def sanitize_name(s: str, fallback="auto"):
    base = re.sub(r"[^a-zA-Z0-9_]", "_", s.strip()) or fallback
    base = re.sub(r"_+", "_", base).strip("_")
    return base[:40] if base else fallback

def extract_features(text: str):
    # Very light heuristics to guess signals, clocks, resets, widths
    toks = re.findall(r"\b[a-zA-Z_][a-zA-Z0-9_\[\]:]*\b", text)
    clocks = [t for t in toks if re.search(r"clk|clock", t, re.I)][:3]
    resets = [t for t in toks if re.search(r"rst|reset|areset|srst", t, re.I)][:3]
    sigs   = [t for t in toks if re.search(r"(valid|ready|req|ack|id|data|addr|resp)", t, re.I)][:20]
    return {"clocks":clocks, "resets":resets, "signals":sigs}

def sv_run_md(test_name):
    return f"""# RUN.md
Steps to compile and run (example, adjust to your toolchain):

1. Compile:
   ```sh
   vlog -sv tb_pkg.sv seq.sv uvm_test.sv
   ```

2. Run:
   ```sh
   vsim -c -do "run -all" -sv_lib tb_pkg +UVM_TESTNAME={test_name}
   ```

3. TODO: Bind your DUT and env in `tb_pkg.sv` and connect agents.
"""

def sv_tb_pkg(pkg_name, test_name):
    return f"""// tb_pkg.sv
package {pkg_name};
  import uvm_pkg::*;
  `include "uvm_macros.svh"

  // TODO: typedefs, interfaces, transactions
  // TODO: bind DUT or include top-level tb

  function void run_the_test();
    run_test("{test_name}");
  endfunction

endpackage : {pkg_name}
"""

def sv_seq(seq_name, signals):
    sig_comment = ", ".join(signals) if signals else "/* add signals */"
    return f"""// seq.sv
`include "uvm_macros.svh"
import uvm_pkg::*;

class {seq_name} extends uvm_sequence #(uvm_sequence_item);
  `uvm_object_utils({seq_name})

  function new(string name="{seq_name}");
    super.new(name);
  endfunction

  virtual task body();
    `uvm_info(get_type_name(), "Starting sequence", UVM_MEDIUM)
    // TODO: drive transactions; suspected signals: {sig_comment}
    // Example:
    // repeat (10) begin
    //   // drive stimulus here
    // end
  endtask
endclass : {seq_name}
"""

def sv_test(test_name, pkg_name, seq_name, features):
    clocks = ", ".join(features.get("clocks", [])) or "/*clk*/"
    resets = ", ".join(features.get("resets", [])) or "/*rst*/"
    return f"""// uvm_test.sv
`include "uvm_macros.svh"
import uvm_pkg::*;
import {pkg_name}::*;

class {test_name} extends uvm_test;
  `uvm_component_utils({test_name})

  function new(string name="{test_name}", uvm_component parent=null);
    super.new(name, parent);
  endfunction

  virtual function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    // TODO: configure env, agents, virtual interfaces
  endfunction

  virtual task run_phase(uvm_phase phase);
    phase.raise_objection(this);
    `uvm_info(get_type_name(), "Clocks: {clocks} Resets: {resets}", UVM_LOW)
    {seq_name} seq = {seq_name}::type_id::create("seq");
    seq.start(null);
    phase.drop_objection(this);
  endtask

  // TODO: add covergroups and assertions
endclass : {test_name}
"""

def request_data_checklist():
    return """### Request Data Checklist
- Exact test / seed / regression bucket
- Tool versions (simulator, UVM, OS)
- Commit hashes of DUT and env
- Error logs with timestamps
- Waveform signals: clk, rst, valid/ready, addr, data, id, resp
- Steps to reproduce with probability of hit
"""

def provide_options():
    return [
        "Generate only sequence skeleton",
        "Ask reporter for minimal repro package",
        "Search top-5 similar Jira fixes",
        "Open a new investigation task with attached checklist"
    ]

def generate_sv_bundle(outdir: Path, jira_text: str, names: dict):
    outdir.mkdir(parents=True, exist_ok=True)
    feats = extract_features(jira_text)
    test_name = sanitize_name(names.get("test_name") or "auto_repro_test")
    seq_name  = sanitize_name(names.get("seq_name")  or "auto_repro_seq")
    pkg_name  = sanitize_name(names.get("pkg_name")  or "auto_tb_pkg")

    (outdir / "RUN.md").write_text(sv_run_md(test_name), encoding="utf-8")
    (outdir / "tb_pkg.sv").write_text(sv_tb_pkg(pkg_name, test_name), encoding="utf-8")
    (outdir / "seq.sv").write_text(sv_seq(seq_name, feats.get("signals")), encoding="utf-8")
    (outdir / "uvm_test.sv").write_text(sv_test(test_name, pkg_name, seq_name, feats), encoding="utf-8")
    return ["RUN.md","tb_pkg.sv","seq.sv","uvm_test.sv"]
