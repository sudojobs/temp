
let filesCache = {};
function spin(on){document.getElementById('spinner').style.display = on?'flex':'none';}

function setCfgSummary(cfg){
  const r = cfg.recipes || {};
  const on = Object.keys(r).filter(k=>r[k]).length;
  const total = Object.keys(r).length;
  document.getElementById("cfgsummary").textContent = `Recipes ON: ${on}/${total} | Port ${cfg.port}`;
  // Reflect LLM config into dropdown
  if(cfg.llm && cfg.llm.model){
    document.getElementById("model").value = cfg.llm.model;
  }
  if(cfg.llm && typeof cfg.llm.temperature === "number"){
    document.getElementById("temp").value = cfg.llm.temperature;
  }
}

async function getConfig(){
  const r = await fetch("/api/config");
  const cfg = await r.json();
  setCfgSummary(cfg); renderToggles(cfg);
}
getConfig();

function switchTab(el){
  document.querySelectorAll(".tab").forEach(t=>t.classList.remove("active"));
  el.classList.add("active");
  const tab = el.getAttribute("data-tab");
  document.getElementById("out").style.display = tab==="out"?"block":"none";
  document.getElementById("preview").style.display = tab==="preview"?"block":"none";
}

function jiraText(){ return document.getElementById("jira").value.trim(); }

function showOut(obj){
  document.getElementById("outpre").textContent = typeof obj === "string" ? obj : JSON.stringify(obj, null, 2);
}

async function train(){
  showOut("Training TF-IDF...");
  spin(true); const r = await fetch("/api/train", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({})}); spin(false);
  const j = await r.json();
  showOut(j);
}

async function match(){
  const text = jiraText();
  spin(true); const r = await fetch("/api/match_old_fixes", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({text})}); spin(false);
  const j = await r.json();
  showOut(j);
}

async function genHeuristic(){
  const jira_text = jiraText();
  const payload = {jira_text, test_name:"auto_repro_test", seq_name:"auto_repro_seq", pkg_name:"auto_tb_pkg"};
  spin(true); const r = await fetch("/api/generate_testcase", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)}); spin(false);
  const j = await r.json();
  showOut(j);
  if(j.ok && j.files){
    const c = j.contents || {};
    filesCache = {};
    filesCache = {};
    const sel = document.getElementById("pvsel");
    sel.innerHTML = "";
    for(const path of j.files){
      const name = path.split("/").pop();
      filesCache[name] = {path, content: c[name] || null};
      const opt = document.createElement("option");
      opt.value = name; opt.textContent = name;
      sel.appendChild(opt);
    }
    document.querySelector('[data-tab="preview"]').click();
    loadPreview();
  }
}

async function genLLM(){
  return streamLLM();
}
async function genLLM_old(){
  const jira_text = jiraText();
  const model = document.getElementById("model").value;
  const temperature = parseFloat(document.getElementById("temp").value||"0.1");
  // also persist to config at runtime (in-memory only; server uses config.json defaults otherwise)
  spin(true); const r = await fetch("/api/generate_llm_testcase", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({jira_text, llm:{model, temperature}})}); spin(false);
  const j = await r.json();
  showOut(j);
  if(j.ok && j.files){
    const c = j.contents || {};
    filesCache = {};
    const sel = document.getElementById("pvsel");
    sel.innerHTML = "";
    filesCache = {};
    for(const path of j.files){
      const name = path.split("/").pop();
      filesCache[name] = {path, content: c[name] || null};
      const opt = document.createElement("option");
      opt.value = name; opt.textContent = name;
      sel.appendChild(opt);
    }
    const dl = document.getElementById("dl");
    if(j.zip){ dl.style.display="inline-block"; dl.href = j.zip; }
    document.querySelector('[data-tab="preview"]').click();
    loadPreview();
  }
}

async function loadPreview(){
  const sel = document.getElementById("pvsel");
  const name = sel.value;
  const item = filesCache[name];
  if(!item) return;
  // Fetch file content via plain GET (server serves static cwd root only for / and /ui/, so disable; show path hint instead)
  document.getElementById("pv").textContent = (item.content? item.content : `Open on disk: ${item.path}\n\n(Use the download button for a zip bundle.)`);
}

document.getElementById("pvsel").addEventListener("change", loadPreview);


async function renderToggles(cfg){
  const t = cfg.recipes || {};
  const wrap = document.getElementById("toggles");
  wrap.innerHTML = "";
  Object.keys(t).forEach(key=>{
    const el = document.createElement("label");
    el.className = "switch";
    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.checked = t[key];
    chk.onchange = async () => {
      await fetch("/api/config/update", {method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({recipes: {[key]: chk.checked}})});
      const res = await fetch("/api/config"); const nc = await res.json();
      setCfgSummary(nc); renderToggles(nc);
    };
    const span = document.createElement("span");
    span.textContent = key;
    el.appendChild(chk); el.appendChild(span);
    wrap.appendChild(el);
  });
}

function copyCurrent(){
  const sel = document.getElementById("pvsel");
  if(!sel.value) return;
  const item = filesCache[sel.value];
  const text = item && item.content ? item.content : document.getElementById("pv").textContent;
  navigator.clipboard.writeText(text || "").then(()=>{
    showOut("Copied to clipboard: " + sel.value);
  }).catch(()=>{
    showOut("Copy failed.");
  });
}

async function streamLLM(){
  const text = jiraText();
  const model = document.getElementById("model").value;
  const temp = document.getElementById("temp").value || "0.1";
  showOut("Streaming from local LLM...");
  document.querySelector('[data-tab="out"]').click();
  spin(true);
  const es = new EventSource(`/api/stream_llm?text=${encodeURIComponent(text)}&model=${encodeURIComponent(model)}&temp=${encodeURIComponent(temp)}`);
  let acc = "";
  es.onmessage = (e)=>{
    try{
      const obj = JSON.parse(e.data);
      if(obj.done){
        spin(false);
        // expose download
        const dl = document.getElementById("dl");
        if(obj.zip){ dl.style.display="inline-block"; dl.href = obj.zip; }
        es.close();
        return;
      }
    }catch(_){}
    acc += e.data;
    document.getElementById("outpre").textContent = acc;
  };
  es.onerror = ()=>{ spin(false); es.close(); };
}
