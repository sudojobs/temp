#!/usr/bin/env bash
set -e
python3 server.py
